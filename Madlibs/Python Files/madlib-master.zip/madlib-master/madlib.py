adjective3 = input("Enter an adjective: ")
verb = input("Enter a verb: ")
adjective4 = input("Enter another adjective: ")
adjective2 = input("Enter another adjective: ")
verb_past_tense2 = input("Enter a verb past tense: ")
noun2 = input("Enter a noun: ")
verb_past_tense = input("Enter a verb past tense: ")
adverb = input("Enter an adverb: ")
noun3 = input("Enter another noun: ")
adverb2 = input("Enter another verb: ")
adjective = input("Enter  another adjective: ")
noun = input("Enter another noun: ")



print("A day at the zoo! Today I went to the zoo. I saw a {} {} jumping up and down on its tree. He {} {} through the large tunnel that led to its {} {} I got some peanuts and passed them through the cage to a gigantic gray {} towering above my head. Feeding that animal made me hungry. I went to get a {} scoop of ice cream. It filled my stomach. Afterwards I had to {} {} to catch our bus. When I got home I {} my mom for a {} day at the zoo.".format(adjective, noun, verb_past_tense, adverb, adjective2, noun2, noun3, adjective3, verb, adverb2, verb_past_tense2, adjective4))