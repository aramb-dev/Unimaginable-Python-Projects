

print("THE MIKIAN")
print("Once apon a time the")
print("_________(adjective)")
p1 = input()
print("Mikian rode a")
print("_________(adjective)")
p2 = input()
print("_________(animal)")
p3 = input()
print("and tought people")
print("_________(a coding language).")
p4 = input()

print("Once apon a time the", p1, "Mikian rode a", p2, p3, "and tought people", p4 + ".")
