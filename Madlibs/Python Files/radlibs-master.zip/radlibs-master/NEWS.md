
# radlibs 0.2.0

This version adds the ability to reuse a single word multiple times in your radlibs string. 
It also introduces a requirement that the keywords be enclosed in curly braces. This is a breaking change.

# radlibs 0.1.0

Welcome to radlibs! This package contains functions to take a phrase or passage of text and substitute
the words "noun" or "verb" (or others) with silly words from the same part of speech. The README file
gives full details about what is supported.
