#!/usr/bin/env python3

from radlibsme.radlibsme import app

app(prog_name="python -m radlibsme")
