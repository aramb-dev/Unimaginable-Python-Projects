# ensuring that global binding for part of speech obj is found
utils::globalVariables(c("pos"))