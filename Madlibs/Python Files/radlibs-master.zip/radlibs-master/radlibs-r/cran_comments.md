## v0.2.0

Submission 2

- Ensured top level does not include docs or cran_comments.md.

Submission 1

- Added feature allowing user to designate words for repetition.
- Made one breaking change to require keywords to be enclosed in curly braces.

## v0.1.0

### Testing

Submission 2

- Removed README.html
- Removed radlibs_0.1.0.tar.gz
- Removed dependency on qdap (was requiring excessively complex Java management on part of users)
- Converted proper_nouns.rda to ASCII from binary

Submission 1

- Local macOS, R version 3.5.3
- There is one warning for a non-ASCII character in data. This is due to special symbols in Bjork's name.

